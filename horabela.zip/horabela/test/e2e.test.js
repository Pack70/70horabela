/* Teste de ponta a ponta: cadastro → página pública → solicitação → WhatsApp → confirmação → admin */
const assert = require('assert');
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { chromium } = require('playwright');

const PORT = 3200 + Math.floor(Math.random() * 500);
const BASE = 'http://localhost:' + PORT;
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'hb-e2e-'));
const SHOTS = process.env.SHOTS || '';
const PIC = process.env.PIC || path.join(__dirname, 'pic.png');
let server;

const shot = async (page, name) => { if (SHOTS) await page.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: false }); };
const step = (m) => console.log('• ' + m);

async function startServer() {
  server = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(__dirname, '..', 'src', 'server.js')], {
    env: { ...process.env, PORT, DATA_DIR: DATA, ADMIN_EMAIL: 'dono@horabela.test', ADMIN_PASSWORD: 'admin-senha-123', TZ: 'America/Sao_Paulo' }, stdio: ['ignore', 'pipe', 'inherit'],
  });
  await new Promise((res, rej) => { server.stdout.on('data', (d) => { if (String(d).includes('rodando')) res(); }); server.on('exit', () => rej(new Error('servidor caiu'))); setTimeout(() => rej(new Error('timeout')), 8000); });
}

async function register(page, name, email) {
  await page.goto(BASE + '/cadastro');
  await page.fill('[name=name]', name); await page.fill('[name=email]', email); await page.fill('[name=password]', 'senha-segura-1');
  await page.click('button[type=submit]');
  await page.waitForURL('**/configurar');
}

async function wizard(page, { slug, business, whatsapp, avatar }) {
  await page.fill('[name=business]', business);
  await page.fill('[name=specialties]', 'Design de sobrancelhas, Brow lamination');
  await page.fill('[name=bio]', 'Realce o seu olhar com técnica e cuidado.');
  await page.click('button[type=submit]');
  if (avatar) {
    const [fc] = await Promise.all([page.waitForEvent('filechooser'), page.click('[data-act=w-avatar]')]);
    await fc.setFiles(PIC);
    await page.waitForSelector('#w-av img');
  }
  await page.click('button[type=submit]');
  await page.fill('[name=whatsapp]', whatsapp);
  await page.fill('[name=instagram]', '@' + slug.replace(/-/g, ''));
  await page.fill('[name=address]', 'Rua das Flores, 123 — Vila Mariana, São Paulo');
  await page.click('button[type=submit]');
  await page.fill('[name=slug]', slug);
  await page.waitForSelector('#slug-msg.okmsg, #slug-msg.errmsg');
}

async function addService(page, name, price, dur) {
  await page.click('[data-act=svc-new]');
  await page.fill('.sheet [name=name]', name); await page.fill('.sheet [name=price]', price); await page.selectOption('.sheet [name=duration]', String(dur));
  await page.click('.sheet button[type=submit]');
  await page.waitForSelector('.sheet', { state: 'detached' });
}

(async () => {
  await startServer();
  const browser = await chromium.launch();
  const mobile = { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'pt-BR', timezoneId: 'America/Sao_Paulo' };
  const errors = [];
  const watch = (page) => { page.on('pageerror', (e) => errors.push('pageerror: ' + e.message)); page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource|fonts\.g/.test(m.text())) errors.push('console: ' + m.text()); }); };
  const api = async (method, url, body, cookie) => { const r = await fetch(BASE + url, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: method === 'GET' ? undefined : JSON.stringify(body || {}) }); return { status: r.status, data: await r.json().catch(() => null), setCookie: r.headers.get('set-cookie') }; };

  try {
    /* ---- 1. Landing ---- */
    const ctxA = await browser.newContext(mobile); const pa = await ctxA.newPage(); watch(pa);
    await pa.goto(BASE + '/');
    assert.ok(await pa.locator('h1', { hasText: 'Sua agenda de beleza, organizada em um só lugar.' }).count(), 'título da landing');
    assert.ok(await pa.locator('text=Criar minha página grátis').count(), 'CTA');
    assert.strictEqual(await pa.locator('.plan').count(), 3, 'três planos');
    await shot(pa, '01-landing-mobile');
    step('landing ok');

    /* ---- 2. Cadastro + assistente ---- */
    await register(pa, 'Maria Silva', 'maria@teste.com');
    await wizard(pa, { slug: 'maria-beleza', business: 'Maria Beauty', whatsapp: '(11) 91234-5678', avatar: true });
    await shot(pa, '02-wizard-4');
    // slug reservado e inválido
    await pa.fill('[name=slug]', 'admin'); await pa.waitForFunction(() => /reservado/.test(document.querySelector('#slug-msg').textContent));
    await pa.fill('[name=slug]', 'maria-beleza'); await pa.waitForFunction(() => /disponível/.test(document.querySelector('#slug-msg').textContent));
    await pa.click('button[type=submit]');
    await pa.waitForURL('**/painel/servicos**');
    step('cadastro e assistente ok');

    /* ---- 3. Serviços ---- */
    await pa.waitForSelector('.sheet');
    await pa.fill('.sheet [name=name]', 'Design de sobrancelhas'); await pa.fill('.sheet [name=price]', '40,00'); await pa.selectOption('.sheet [name=duration]', '30');
    await pa.click('.sheet button[type=submit]'); await pa.waitForSelector('.sheet', { state: 'detached' });
    await addService(pa, 'Design com henna', '55,00', 45);
    await addService(pa, 'Brow lamination', '120,00', 60);
    await pa.waitForFunction(() => document.querySelectorAll('.svc').length === 3);
    await shot(pa, '03-servicos');
    step('serviços ok');

    /* ---- 4. Página pública (cliente anônima, outro contexto) ---- */
    const ctxC = await browser.newContext(mobile); const pc = await ctxC.newPage(); watch(pc);
    let waUrl = null;
    await ctxC.route('https://wa.me/**', (route) => { waUrl = route.request().url(); route.fulfill({ status: 200, contentType: 'text/html', body: '<h1>WhatsApp</h1>' }); });
    await pc.goto(BASE + '/maria-beleza');
    await pc.waitForSelector('.psvc');
    assert.strictEqual(await pc.locator('.psvc').count(), 3);
    assert.ok(await pc.locator('text=R$ 55,00').count(), 'preço visível');
    assert.ok(await pc.locator('text=45 minutos').count(), 'duração visível');
    assert.strictEqual(await pc.locator('input[type=search], [placeholder*=Buscar]').count(), 0, 'sem busca');
    await shot(pc, '04-publica');
    await pc.locator('.psvc', { hasText: 'Design com henna' }).locator('button').click();
    await pc.waitForSelector('.cal-d.avail');
    await pc.locator('.cal-d.avail').first().click();
    const slotBtn = pc.locator('.slot').nth(2); const chosenTime = (await slotBtn.textContent()).trim();
    const chosenDate = await pc.evaluate(() => document.querySelector('.cal-d.sel').dataset.d);
    await slotBtn.click();
    await shot(pc, '05-escolher-horario');
    await pc.click('[data-bk=to-info]');
    // validação do telefone
    await pc.fill('[name=name]', 'Ana'); await pc.fill('[name=phone]', '123');
    await pc.click('[data-bk=to-summary]');
    assert.ok((await pc.locator('.errmsg').allTextContents()).join('').includes('telefone'), 'valida telefone');
    await pc.fill('[name=phone]', '(21) 99876-5432');
    await pc.click('[data-bk=to-summary]');
    await pc.waitForSelector('.summary');
    const sum = await pc.locator('.summary').innerText();
    assert.ok(/Design com henna/.test(sum) && /R\$ 55,00/.test(sum) && /Maria Silva/.test(sum) && new RegExp(chosenTime.replace(':', 'h')).test(sum), 'resumo completo: ' + sum);
    await shot(pc, '06-resumo');
    await pc.click('[data-bk=send]');
    await pc.waitForFunction(() => document.body.innerText.includes('WhatsApp') && location.hostname !== 'localhost', null, { timeout: 8000 }).catch(() => {});
    for (let i = 0; i < 40 && !waUrl; i++) await pc.waitForTimeout(100);
    assert.ok(waUrl, 'abriu wa.me');
    const u = new URL(waUrl);
    assert.strictEqual(u.pathname, '/5511912345678', 'número da profissional');
    const text = u.searchParams.get('text');
    const [yy, mm, dd] = chosenDate.split('-');
    assert.ok(text.startsWith('Olá, Maria! Gostaria de solicitar um agendamento.'), text);
    assert.ok(text.includes('Nome: Ana') && text.includes('Procedimento: Design com henna') && text.includes('Data: ' + dd + '/' + mm + '/' + yy) && text.includes('Horário: ' + chosenTime.replace(':', 'h')) && text.includes('Valor: R$ 55,00') && text.includes('Aguardo a confirmação. Obrigada!'), text);
    step('solicitação + link do WhatsApp ok → ' + text.split('\n').slice(2, 6).join(' | '));

    /* ---- 5. Bloqueio de horário ocupado (pendente reserva o slot) ---- */
    const svcs = (await api('GET', '/api/public/maria-beleza')).data.services;
    const henna = svcs.find((s) => s.name === 'Design com henna');
    const slots = (await api('GET', '/api/public/maria-beleza/slots?service=' + henna.id)).data.days;
    assert.ok(!(slots[chosenDate] || []).includes(chosenTime), 'horário pendente não é mais oferecido');
    const dup = await api('POST', '/api/public/maria-beleza/bookings', { serviceId: henna.id, date: chosenDate, time: chosenTime, name: 'Bia', phone: '11988887777' });
    assert.strictEqual(dup.status, 409, 'conflito rejeitado no servidor');
    // sobreposição parcial (henna 45min às X; lamination 60min começando 30min antes)
    step('conflitos ok');

    /* ---- 6. Painel: pendente → confirmar ---- */
    await pa.goto(BASE + '/painel');
    await pa.waitForSelector('.stat');
    assert.ok((await pa.locator('.stat.hot b').textContent()).trim() === '1', 'pendente no painel');
    await pa.goto(BASE + '/painel/agendamentos');
    await pa.waitForSelector('.bk');
    assert.ok(await pa.locator('.bk .chip.warn', { hasText: 'Pendente de confirmação' }).count());
    await shot(pa, '07-agendamentos');
    await pa.click('[data-act=bk-confirm]');
    await pa.waitForSelector('.sheet a.btn-wa');
    const notify = decodeURIComponent(await pa.getAttribute('.sheet a.btn-wa', 'href'));
    assert.ok(notify.includes('wa.me/5521998765432') && notify.includes('confirmado'), 'aviso para a cliente: ' + notify);
    await pa.click('.sheet [data-close]:not(a)');
    await pa.click('[data-act=bk-tab][data-v=confirmed]');
    await pa.waitForSelector('.bk .chip.ok');
    step('confirmação pela profissional ok');
    // cliente vê status
    await pc.goto(BASE + '/maria-beleza'); await pc.waitForSelector('#my-req .chip');
    assert.ok(/Confirmado/.test(await pc.locator('#my-req').innerText()), 'cliente vê confirmado');

    /* ---- 7. Agenda, remarcar e concluir ---- */
    await pa.goto(BASE + '/painel/agenda'); await pa.waitForSelector('.page-h');
    await pa.click('[data-act=cal-view][data-v=month]'); await pa.waitForSelector('.cal-month');
    await pa.click('[data-act=cal-view][data-v=week]'); await pa.waitForSelector('.week');
    await pa.click('[data-act=cal-view][data-v=day]');
    await shot(pa, '08-agenda');
    await pa.goto(BASE + '/painel/agendamentos'); await pa.click('[data-act=bk-tab][data-v=confirmed]');
    await pa.click('[data-act=bk-resched]'); await pa.waitForSelector('.sheet .slot');
    const newT = (await pa.locator('.sheet .slot').last().textContent()).trim();
    await pa.locator('.sheet .slot').last().click(); await pa.click('.sheet button[type=submit]');
    await pa.waitForSelector('.sheet a.btn-wa'); await pa.click('.sheet [data-close]:not(a)');
    await pa.waitForSelector('.chip.rose');
    assert.ok(await pa.locator('.bk', { hasText: HBtime(newT) }).count(), 'remarcado para ' + newT);
    step('remarcação ok');

    /* ---- 8. Disponibilidade: bloqueio de data (plano grátis é barrado; admin muda plano depois) ---- */
    const login = await api('POST', '/api/auth/login', { email: 'maria@teste.com', password: 'senha-segura-1' });
    const cookieA = login.setCookie.split(';')[0];
    const blk = await api('POST', '/api/blocks', { startDate: chosenDate, endDate: chosenDate, allDay: true }, cookieA);
    assert.strictEqual(blk.status, 403, 'plano grátis não cria bloqueio');

    /* ---- 9. Isolamento entre profissionais ---- */
    const ctxB = await browser.newContext(mobile); const pb = await ctxB.newPage(); watch(pb);
    await register(pb, 'Joana Costa', 'joana@teste.com');
    await wizard(pb, { slug: 'joana-nails', business: 'Joana Nails', whatsapp: '(31) 98888-1111' });
    await pb.fill('[name=slug]', 'maria-beleza'); await pb.waitForFunction(() => /em uso/.test(document.querySelector('#slug-msg').textContent));
    await pb.click('button[type=submit]');
    await pb.waitForTimeout(600); assert.ok(pb.url().includes('/configurar') && /em uso/.test(await pb.locator('#slug-msg').innerText()), 'slug duplicado impedido');
    await pb.fill('[name=slug]', 'joana-nails'); await pb.waitForFunction(() => /disponível/.test(document.querySelector('#slug-msg').textContent));
    await pb.click('button[type=submit]'); await pb.waitForURL('**/painel/servicos**');
    const loginB = await api('POST', '/api/auth/login', { email: 'joana@teste.com', password: 'senha-segura-1' });
    const cookieB = loginB.setCookie.split(';')[0];
    const bkA = (await api('GET', '/api/bookings', null, cookieA)).data.items;
    assert.strictEqual(bkA.length, 1);
    assert.strictEqual((await api('GET', '/api/bookings', null, cookieB)).data.items.length, 0, 'B não vê agenda de A');
    assert.strictEqual((await api('PATCH', '/api/bookings/' + bkA[0].id + '/status', { status: 'cancelled' }, cookieB)).status, 404, 'B não altera agendamento de A');
    assert.strictEqual((await api('GET', '/api/clients', null, cookieB)).data.items.length, 0, 'B não vê clientes de A');
    assert.strictEqual((await api('GET', '/api/admin/users', null, cookieB)).status, 403, 'B não acessa admin');
    assert.strictEqual((await api('GET', '/api/bookings')).status, 401, 'sem login = 401');
    const pubA = JSON.stringify((await api('GET', '/api/public/maria-beleza')).data);
    assert.ok(!/maria@teste|pass|11912345678/.test(pubA), 'página pública não vaza dados privados');
    // upload malicioso
    assert.strictEqual((await api('POST', '/api/upload', { dataUrl: 'data:image/png;base64,' + Buffer.from('<script>alert(1)</script>').toString('base64') }, cookieA)).status, 400, 'arquivo falso rejeitado');
    // XSS no nome da cliente
    const x = await api('POST', '/api/public/maria-beleza/bookings', { serviceId: henna.id, date: Object.keys(slots).find((d) => d !== chosenDate), time: slots[Object.keys(slots).find((d) => d !== chosenDate)][0], name: '<img src=x onerror=window.__xss=1>', phone: '11977776666' });
    assert.strictEqual(x.status, 200);
    await pa.goto(BASE + '/painel/agendamentos'); await pa.waitForSelector('.bk');
    assert.strictEqual(await pa.evaluate(() => window.__xss), undefined, 'sem XSS');
    step('isolamento e segurança ok');

    /* ---- 10. Expiração da reserva temporária ---- */
    const { DatabaseSync } = require('node:sqlite');
    const db = new DatabaseSync(path.join(DATA, 'horabela.db'));
    const xdate = Object.keys(slots).find((d) => d !== chosenDate); const xtime = slots[xdate][0];
    let s2 = (await api('GET', '/api/public/maria-beleza/slots?service=' + henna.id)).data.days;
    assert.ok(!(s2[xdate] || []).includes(xtime), 'reservado');
    db.prepare("UPDATE bookings SET hold_expires_at = ? WHERE status='pending'").run(Date.now() - 1000);
    s2 = (await api('GET', '/api/public/maria-beleza/slots?service=' + henna.id)).data.days;
    assert.ok((s2[xdate] || []).includes(xtime), 'reserva expirada libera o horário');
    db.close();
    step('reserva temporária expira ok');

    /* ---- 11. Admin ---- */
    const ctxD = await browser.newContext({ viewport: { width: 1280, height: 800 }, locale: 'pt-BR' }); const pd = await ctxD.newPage(); watch(pd);
    await pd.goto(BASE + '/entrar'); await pd.fill('[name=email]', 'dono@horabela.test'); await pd.fill('[name=password]', 'admin-senha-123'); await pd.click('button[type=submit]');
    await pd.waitForURL('**/admin'); await pd.waitForSelector('.stat');
    await shot(pd, '09-admin');
    await pd.goto(BASE + '/admin/contas'); await pd.waitForSelector('.tbl tbody tr');
    assert.strictEqual(await pd.locator('.tbl tbody tr').count(), 2, 'duas profissionais');
    assert.ok(!(await pd.content()).includes('Ana'), 'admin não vê nome de clientes');
    // plano Profissional para Maria → bloqueio liberado
    await pd.locator('tr', { hasText: 'maria@teste.com' }).locator('select').selectOption('pro');
    await pd.waitForSelector('.toast');
    const blk2 = await api('POST', '/api/blocks', { startDate: chosenDate, endDate: chosenDate, allDay: true, reason: 'Férias' }, cookieA);
    assert.strictEqual(blk2.status, 200, 'plano pro cria bloqueio');
    const s3 = (await api('GET', '/api/public/maria-beleza/slots?service=' + henna.id)).data.days;
    assert.ok(!s3[chosenDate], 'dia bloqueado some da página pública');
    // suspender Joana
    pd.once('dialog', () => {});
    await pd.locator('tr', { hasText: 'joana@teste.com' }).locator('[data-act=u-status]').click();
    await pd.click('.sheet [data-ok]');
    await pd.waitForSelector('.chip.bad');
    assert.strictEqual((await api('POST', '/api/auth/login', { email: 'joana@teste.com', password: 'senha-segura-1' })).status, 403, 'suspensa não entra');
    assert.strictEqual((await api('GET', '/api/me', null, cookieB)).data.user, null, 'sessão da suspensa cai');
    assert.strictEqual((await api('GET', '/api/public/joana-nails')).status, 404, 'página da suspensa sai do ar');
    // preços de plano
    await pd.goto(BASE + '/admin/planos'); await pd.waitForSelector('.plan-form');
    await pd.locator('.plan-form[data-id=pro] [name=price]').fill('34,90'); await pd.locator('.plan-form[data-id=pro] button[type=submit]').click(); await pd.waitForSelector('.toast');
    assert.strictEqual((await api('GET', '/api/config')).data.plans.find((p) => p.id === 'pro').priceCents, 3490, 'preço do plano salvo');
    step('admin ok');

    /* ---- 12. Telas finais (desktop do painel) ---- */
    const ctxE = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'pt-BR' }); const pe = await ctxE.newPage(); watch(pe);
    await pe.goto(BASE + '/entrar'); await pe.fill('[name=email]', 'maria@teste.com'); await pe.fill('[name=password]', 'senha-segura-1'); await pe.click('button[type=submit]');
    await pe.waitForURL('**/painel'); await pe.waitForSelector('.stat'); await shot(pe, '10-painel-desktop');
    await pe.goto(BASE + '/painel/link'); await pe.waitForSelector('.link-box'); await shot(pe, '11-link');
    await pe.goto(BASE + '/painel/disponibilidade'); await pe.waitForSelector('.hrow'); await shot(pe, '12-disponibilidade');
    await pe.goto(BASE + '/maria-beleza'); await pe.waitForSelector('.psvc');
    await pe.goto(BASE + '/nao-existe-esta-pagina'); await pe.waitForSelector('.notfound');
    await pe.goto(BASE + '/painel/nada'); await pe.waitForURL('**/painel');

    assert.deepStrictEqual(errors, [], 'erros no console: ' + errors.join(' | '));
    console.log('\nTodos os testes de ponta a ponta passaram ✔');
  } catch (e) {
    console.error('\nFALHOU:', e.message);
    process.exitCode = 1;
  } finally {
    await browser.close(); server.kill(); fs.rmSync(DATA, { recursive: true, force: true });
  }
})();

function HBtime(t) { return t.replace(':', 'h'); }
