const assert = require('assert');
const HB = require('../src/logic.js');
let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };

const NOW = new Date(2026, 9, 29, 11, 47).getTime(); // qui 29/10/2026 11:47
const hours = HB.defaultHours();
const settings = { minNoticeHours: 2, maxAdvanceDays: 60, slotStep: 30, holdMinutes: 120 };
const base = { duration: 60, hours, settings, bookings: [], blocks: [], nowMs: NOW };

t('formatação', () => {
  assert.strictEqual(HB.brl(5500), 'R$ 55,00');
  assert.strictEqual(HB.brl(123456), 'R$ 1.234,56');
  assert.strictEqual(HB.timeLabel('14:30'), '14h30');
  assert.strictEqual(HB.durLabel(90), '1h30');
  assert.strictEqual(HB.durLabel(30), '30 minutos');
  assert.strictEqual(HB.dateBR('2026-11-05'), '05/11/2026');
  assert.strictEqual(HB.parsePrice('55,00'), 5500);
  assert.strictEqual(HB.parsePrice('1.250,5'), 125050);
  assert.strictEqual(HB.parsePrice('abc'), null);
});

t('usuário', () => {
  assert.strictEqual(HB.usernameError('maria-beleza'), null);
  assert.ok(HB.usernameError('Maria'));
  assert.ok(HB.usernameError('ma'));
  assert.ok(HB.usernameError('maria--b'));
  assert.ok(HB.usernameError('admin'));
  assert.strictEqual(HB.slugify('Maria Beleza & Cia!'), 'maria-beleza-cia');
  assert.strictEqual(HB.slugify('Ana Júlia'), 'ana-julia');
});

t('telefone', () => {
  assert.strictEqual(HB.normPhone('(11) 91234-5678'), '11912345678');
  assert.strictEqual(HB.normPhone('+55 11 91234-5678'), '11912345678');
  assert.strictEqual(HB.normPhone('1131234567'), '1131234567');
  assert.strictEqual(HB.normPhone('11812345678'), null); // 11 dígitos sem 9
  assert.strictEqual(HB.normPhone('0791234567'), null); // DDD inválido
  assert.strictEqual(HB.normPhone('12345'), null);
});

t('mensagem do WhatsApp', () => {
  const msg = HB.requestMessage({ proName: 'Maria Silva', clientName: 'Ana', serviceName: 'Design com henna', date: '2026-11-05', time: '14:30', price: 5500 });
  assert.strictEqual(msg, 'Olá, Maria! Gostaria de solicitar um agendamento.\n\nNome: Ana\nProcedimento: Design com henna\nData: 05/11/2026\nHorário: 14h30\nValor: R$ 55,00\n\nAguardo a confirmação. Obrigada!');
  const url = HB.waLink('11912345678', msg);
  assert.ok(url.startsWith('https://wa.me/5511912345678?text='));
  assert.ok(!url.includes(' ') && !url.includes('\n'));
  assert.strictEqual(decodeURIComponent(url.split('text=')[1]), msg);
  const tricky = HB.requestMessage({ proName: 'M', clientName: 'Zoé & João #1 100%', serviceName: 'Cílios + brow?', date: '2026-11-05', time: '09:00', price: 100 });
  assert.strictEqual(decodeURIComponent(HB.waLink('11912345678', tricky).split('text=')[1]), tricky);
});

t('horários: expediente, almoço e antecedência', () => {
  // sexta 30/10: 09-18 com almoço 12-13, passo 30, serviço 60min
  const s = HB.computeSlots({ ...base, date: '2026-10-30' });
  assert.strictEqual(s[0], '09:00');
  assert.ok(s.includes('11:00'));
  assert.ok(!s.includes('11:30'), 'não pode invadir o almoço');
  assert.ok(!s.includes('12:00'));
  assert.ok(s.includes('13:00'));
  assert.strictEqual(s[s.length - 1], '17:00');
  // hoje (qui 29, 11:47, antecedência 2h => após 13:47)
  const today = HB.computeSlots({ ...base, date: '2026-10-29' });
  assert.strictEqual(today[0], '14:00');
  // domingo fechado
  assert.deepStrictEqual(HB.computeSlots({ ...base, date: '2026-11-01' }), []);
  // passado
  assert.deepStrictEqual(HB.computeSlots({ ...base, date: '2026-10-20' }), []);
  // além do limite de antecedência
  assert.deepStrictEqual(HB.computeSlots({ ...base, date: '2027-02-05' }), []);
});

t('conflitos e bloqueio temporário', () => {
  const mk = (status, extra) => ({ id: 'b' + Math.random(), date: '2026-10-30', time: '14:00', duration: 60, status, holdExpiresAt: NOW + 3600e3, ...extra });
  let s = HB.computeSlots({ ...base, date: '2026-10-30', bookings: [mk('pending')] });
  assert.ok(!s.includes('14:00') && !s.includes('13:30') && !s.includes('14:30'));
  assert.ok(s.includes('13:00') && s.includes('15:00'));
  // bloqueio expirado libera
  s = HB.computeSlots({ ...base, date: '2026-10-30', bookings: [mk('pending', { holdExpiresAt: NOW - 1 })] });
  assert.ok(s.includes('14:00'));
  // confirmado nunca expira
  s = HB.computeSlots({ ...base, date: '2026-10-30', bookings: [mk('confirmed', { holdExpiresAt: 0 })] });
  assert.ok(!s.includes('14:00'));
  // cancelado libera
  s = HB.computeSlots({ ...base, date: '2026-10-30', bookings: [mk('cancelled')] });
  assert.ok(s.includes('14:00'));
  // serviço longo não cabe antes de um agendamento
  s = HB.computeSlots({ ...base, duration: 90, date: '2026-10-30', bookings: [mk('confirmed')] });
  assert.ok(!s.includes('13:00'), '13:00+90min invade 14:00');
  assert.ok(s.includes('15:00'));
  // remarcação ignora o próprio agendamento
  const b = mk('confirmed');
  s = HB.computeSlots({ ...base, date: '2026-10-30', bookings: [b], excludeId: b.id });
  assert.ok(s.includes('14:00'));
});

t('bloqueios de agenda', () => {
  const ferias = { startDate: '2026-10-30', endDate: '2026-11-03', allDay: true };
  assert.deepStrictEqual(HB.computeSlots({ ...base, date: '2026-10-30', blocks: [ferias] }), []);
  assert.deepStrictEqual(HB.computeSlots({ ...base, date: '2026-11-03', blocks: [ferias] }), []);
  assert.ok(HB.computeSlots({ ...base, date: '2026-11-04', blocks: [ferias] }).length > 0);
  const parcial = { startDate: '2026-10-30', endDate: '2026-10-30', allDay: false, startTime: '15:00', endTime: '17:00' };
  const s = HB.computeSlots({ ...base, date: '2026-10-30', blocks: [parcial] });
  assert.ok(s.includes('14:00') && !s.includes('14:30') && !s.includes('16:30') && s.includes('17:00'));
});

t('confirmar após expirar exige horário livre', () => {
  const a = { id: 'a', date: '2026-10-30', time: '14:00', duration: 60, status: 'pending', holdExpiresAt: NOW - 10 };
  const b = { id: 'b', date: '2026-10-30', time: '14:30', duration: 60, status: 'confirmed' };
  assert.ok(HB.hasConflict(a, [a, b], [], hours, NOW));
  assert.strictEqual(HB.hasConflict(a, [a], [], hours, NOW), null);
});

t('cor de contraste', () => {
  assert.strictEqual(HB.contrastOn('#000000'), '#ffffff');
  assert.strictEqual(HB.contrastOn('#f4d6db'), '#1b1517');
});

console.log('\n' + n + ' grupos de testes passaram');
